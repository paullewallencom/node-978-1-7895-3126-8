const logger = require('./logger');
logger.log('This is an informational message');
