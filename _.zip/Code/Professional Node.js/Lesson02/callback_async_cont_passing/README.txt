This example shows asynchronous continuous passing with callbacks.

To run the example launch:

  node test
