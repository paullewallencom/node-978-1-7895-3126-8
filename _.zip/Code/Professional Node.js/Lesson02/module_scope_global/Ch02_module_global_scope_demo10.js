//file main.js

require('./patcher.js');
const logger = require('./logger');
logger.customMessage();
