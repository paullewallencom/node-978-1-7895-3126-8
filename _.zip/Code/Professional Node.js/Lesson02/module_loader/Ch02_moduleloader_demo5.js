"use strict";

const moduleA = require('./moduleA');
moduleA.run();
