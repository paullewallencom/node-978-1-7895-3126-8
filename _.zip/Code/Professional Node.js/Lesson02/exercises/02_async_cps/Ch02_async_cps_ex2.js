"use strict"

function multiply(a, b) {
    return a * b;
}
console.log("Before");
console.log("Result: " + multiply(2, 4));
console.log("After");
