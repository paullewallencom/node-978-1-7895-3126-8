x = 5;

for (var i = 0; i < x; i++) {
    console.log(x);
}

var x;

// Re-write the above using ES6 syntax and the keyword let
// Why does this example work?
// Answer: Hoisting... Variables can be declared after they have been used