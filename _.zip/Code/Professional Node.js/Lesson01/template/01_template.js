// Exercise 7: Templating
// Using the below constants send an amusing email to the Doc to tell him what you think about his latest hair-brained scheme!

const title = "Dr.";
const firstname = "Emmett";
const surname = "Brown";

const scheme = "";

const CRAZY_HAIR = "Crazy Hair";
const CHARISMA = "Charisma";
const MENTAL_INSANITY = "Bordering on Insane";

const chracteristics = [ CRAZY_HAIR, CHARISMA, MENTAL_INSANITY ];

const email = "";

console.log(email);