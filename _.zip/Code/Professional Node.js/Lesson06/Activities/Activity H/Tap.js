const Thing = require('./Thing');

module.exports = class Tap extends Thing {

  constructor() {
    super();
    this.name = "Tap";
  }
};