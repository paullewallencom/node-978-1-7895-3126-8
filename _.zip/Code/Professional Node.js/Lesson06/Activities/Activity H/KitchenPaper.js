const Thing = require('./Thing');

module.exports = class KitchenPaper extends Thing {

  constructor() {
    super();
    this.name = "Kitchen Paper";
  }
};