module.exports = class Thing {

  constructor() {
  }

  name() {
    return this.name;
  }
};

