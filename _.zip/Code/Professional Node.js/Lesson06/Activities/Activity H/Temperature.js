module.exports = {
    SIMMERING: "SIMMERING",
    MAXIMUM: "MAXIMUM"
};