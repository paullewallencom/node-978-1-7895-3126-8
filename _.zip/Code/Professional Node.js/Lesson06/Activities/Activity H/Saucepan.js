const Thing = require('./Thing');

module.exports = class Saucepan extends Thing {

  constructor() {
    super();
    this.name = "Saucepan";
  }
};