class German {

  constructor() {}

  hi() {
    console.log("Ich spreche Deutsch! (I am speaking German!)");
  }
}

module.exports = German;