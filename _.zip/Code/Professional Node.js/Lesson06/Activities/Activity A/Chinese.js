class Chinese {

  constructor() {}

  hi() {
    console.log("我在說中文! (I am speaking Chinese!)");
  }
}

module.exports = Chinese;