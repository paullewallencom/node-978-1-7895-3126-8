class Spanish {

  constructor() {}

  hi() {
    console.log("estoy hablando español! (I am speaking Spanish!)");
  }
}

module.exports = Spanish;