class Japanese {

  constructor() {}

  hi() {
    console.log("私は日本語を話している! (I am speaking Japanese!)");
  }
}

module.exports = Japanese;