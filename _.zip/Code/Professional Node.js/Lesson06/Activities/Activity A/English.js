class English {

  constructor() {}

  hi() {
    console.log("I am speaking English!");
  }
}

module.exports = English;