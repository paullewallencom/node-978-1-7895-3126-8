class French {

  constructor() {}

  hi() {
    console.log("Je parle français! (I am speaking French!)");
  }
}

module.exports = French;