class DbClient {

  constructor() {

  }

  execute() {
    return  {
      text: 'expensive object'
    }
  }
}
module.exports = DbClient;