class Scrollbar {

  constructor() {

  }

  init () {
    this.visible = false;
  }
}

module.exports = Scrollbar;