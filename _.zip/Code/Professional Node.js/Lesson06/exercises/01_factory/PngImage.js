class PngImage {

    constructor(name) {
        this.name = name;
    }

    test() {
        console.log('This is a png image');
    }
}

module.exports = PngImage;