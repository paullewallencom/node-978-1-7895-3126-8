class GifImage {

    constructor(name) {
        this.name = name;
    }

    test() {
        console.log('This is a gif image');
    }
}

module.exports = GifImage;