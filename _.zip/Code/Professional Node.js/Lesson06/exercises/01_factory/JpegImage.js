class JpegImage {

    constructor(name) {
        this.name = name;
    }

    test() {
        console.log('This is a jpeg image');
    }
}

module.exports = JpegImage;