# Promisify HTTP Client

Imagine you're writing an HTTP email client for a customer. 

Colleagues have suggested that you use the Mailgun API with the mailgun-api client.