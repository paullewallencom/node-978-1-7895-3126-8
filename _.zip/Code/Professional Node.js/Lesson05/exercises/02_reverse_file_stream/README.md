# Composability

Your task is to take a copy of a file from `example.txt` copy the contents of it and reverse it, then output to a file called `reverse.txt`.

You should end up with 2 files:

example.txt:
```
This is an example forward sentence
```

reverse.txt
```
ecnetnes drawrof elpmaxe na se sihT
```

Hint: Leverage existing libraries if you can