"use strict";

const umdModule = require('./umdModule');

console.log(umdModule.sayHello('Server!'));
